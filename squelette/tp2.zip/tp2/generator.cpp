#include "generator.h"
#include "ensitlm.h"
#include "LCDC_registermap.h"

#define MEM_START_ADD 0x10000000
#define VIDEO_START_ADD MEM_START_ADD + (10 * 1024)
#define LCDC_START_ADD 0x00000000
#define ROM_START_ADD 0x10015400


using namespace std;

void Generator::thread(void) {
	/*
	for (uint32_t i = VIDEO_START_ADD; i < VIDEO_START_ADD + 76800; i += 4){
		socket.write(i, 0xFFFFFFFF);
	}
	socket.write(LCDC_ADDR_REG, VIDEO_START_ADD);
	socket.write(LCDC_START_REG, 0x1);
	*/
	ensitlm::data_t read_data;
	ensitlm::data_t write_data_first;
	ensitlm::data_t write_data_second;

	socket.write(LCDC_ADDR_REG, VIDEO_START_ADD);
	socket.write(LCDC_START_REG, 0x1);

	for (uint32_t i = ROM_START_ADD; i < ROM_START_ADD + 0x38400; i += sizeof(ensitlm::addr_t)){
		socket.read(i, read_data);
		for (int j = 0; j < 8; ++j){
			if (j<4){
				write_data_first += ((read_data >> (j*4)) & 0x0000000F) << (j*4);
			} else {
				write_data_second += ((read_data >> ((j-4)*4)) & 0x0000000F) << ((j-4)*4);
			}
		}
		socket.write(i - 0x00015400, write_data_first);
		socket.write(i - 0x00015400, write_data_second);
		write_data_first = 0x00000000;
		write_data_second = 0x00000000;
	}
	
}

Generator::Generator(sc_core::sc_module_name name) : sc_core::sc_module(name) {
	SC_THREAD(thread);
}